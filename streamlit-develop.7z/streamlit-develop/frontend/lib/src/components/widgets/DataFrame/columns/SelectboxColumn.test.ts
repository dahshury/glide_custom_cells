/**
 * Copyright (c) Streamlit Inc. (2018-2022) Snowflake Inc. (2022-2025)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { GridCellKind } from "@glideapps/glide-data-grid"
import { DropdownCellType } from "@glideapps/glide-data-grid-cells"
import { Bool, Field, Int8 } from "apache-arrow"

import { ArrowType, DataFrameCellType } from "~lib/dataframes/arrowTypeUtils"

import SelectboxColumn, { SelectboxColumnParams } from "./SelectboxColumn"
import { BaseColumnProps, isErrorCell, isMissingValueCell } from "./utils"

const MOCK_CATEGORICAL_TYPE: ArrowType = {
  type: DataFrameCellType.DATA,
  arrowField: new Field("selectbox_column", new Int8(), true),
  pandasType: {
    field_name: "selectbox_column",
    name: "selectbox_column",
    pandas_type: "int8",
    numpy_type: "int8",
    metadata: null,
  },
}

const MOCK_BOOLEAN_ARROW_TYPE: ArrowType = {
  type: DataFrameCellType.DATA,
  arrowField: new Field("selectbox_column", new Bool(), true),
  pandasType: {
    field_name: "selectbox_column",
    name: "selectbox_column",
    pandas_type: "bool",
    numpy_type: "bool",
    metadata: null,
  },
}

const SELECTBOX_COLUMN_TEMPLATE: Partial<BaseColumnProps> = {
  id: "1",
  name: "selectbox_column",
  title: "Selectbox column",
  indexNumber: 0,
  isEditable: true,
  isHidden: false,
  isIndex: false,
  isPinned: false,
  isStretched: false,
}

function getSelectboxColumn(
  arrowType: ArrowType,
  params?: SelectboxColumnParams,
  column_props_overwrites?: Partial<BaseColumnProps>
): ReturnType<typeof SelectboxColumn> {
  return SelectboxColumn({
    ...SELECTBOX_COLUMN_TEMPLATE,
    ...column_props_overwrites,
    arrowType,
    columnTypeOptions: params,
  } as BaseColumnProps)
}

describe("SelectboxColumn", () => {
  it("creates a valid column instance with string values", () => {
    const mockColumn = getSelectboxColumn(MOCK_CATEGORICAL_TYPE, {
      options: ["foo", "bar"],
    })
    expect(mockColumn.kind).toEqual("selectbox")
    expect(mockColumn.title).toEqual(SELECTBOX_COLUMN_TEMPLATE.title)
    expect(mockColumn.id).toEqual(SELECTBOX_COLUMN_TEMPLATE.id)
    expect(mockColumn.sortMode).toEqual("default")

    const mockCell = mockColumn.getCell("foo")
    expect(mockCell.kind).toEqual(GridCellKind.Custom)
    expect(mockColumn.getCellValue(mockCell)).toEqual("foo")

    expect((mockCell as DropdownCellType).data.allowedValues).toEqual([
      null,
      "foo",
      "bar",
    ])
  })

  it("creates a valid column instance number values", () => {
    const mockColumn = getSelectboxColumn(MOCK_CATEGORICAL_TYPE, {
      options: [1, 2, 3],
    })
    expect(mockColumn.kind).toEqual("selectbox")
    expect(mockColumn.title).toEqual(SELECTBOX_COLUMN_TEMPLATE.title)
    expect(mockColumn.id).toEqual(SELECTBOX_COLUMN_TEMPLATE.id)
    expect(mockColumn.sortMode).toEqual("default")

    const mockCell = mockColumn.getCell(1)
    expect(mockCell.kind).toEqual(GridCellKind.Custom)
    expect(mockColumn.getCellValue(mockCell)).toEqual(1)

    expect((mockCell as DropdownCellType).data.allowedValues).toEqual([
      null,
      "1",
      "2",
      "3",
    ])
  })

  it("creates a valid column instance from boolean type", () => {
    const mockColumn = getSelectboxColumn(MOCK_BOOLEAN_ARROW_TYPE)
    expect(mockColumn.kind).toEqual("selectbox")
    expect(mockColumn.title).toEqual(SELECTBOX_COLUMN_TEMPLATE.title)

    const mockCell = mockColumn.getCell(true)
    expect(mockCell.kind).toEqual(GridCellKind.Custom)
    expect(mockColumn.getCellValue(mockCell)).toEqual(true)

    expect((mockCell as DropdownCellType).data.allowedValues).toEqual([
      null,
      "true",
      "false",
    ])
  })

  it("creates a required column that does not add the empty value", () => {
    const mockColumn = getSelectboxColumn(
      MOCK_CATEGORICAL_TYPE,
      {
        options: ["foo", "bar"],
      },
      { isRequired: true }
    )
    const mockCell = mockColumn.getCell("foo")
    expect((mockCell as DropdownCellType).data.allowedValues).toEqual([
      "foo",
      "bar",
    ])

    const errorCell = mockColumn.getCell(null, true)
    expect(isErrorCell(errorCell)).toEqual(true)
  })

  it("uses faded style for pinned columns", () => {
    const mockColumn = getSelectboxColumn(
      MOCK_CATEGORICAL_TYPE,
      {
        options: ["foo", "bar"],
      },
      {
        isPinned: true,
      }
    )

    const mockCell = mockColumn.getCell("foo")
    expect(mockCell.style).toEqual("faded")
  })

  it("creates error cell if value is not in options", () => {
    const mockColumn = getSelectboxColumn(MOCK_CATEGORICAL_TYPE, {
      options: ["foo", "bar"],
    })
    const mockCell = mockColumn.getCell("baz", true)
    expect(isErrorCell(mockCell)).toEqual(true)
  })

  it.each([[null], [undefined], [""]])(
    "%p is interpreted as missing value",
    // eslint-disable-next-line @typescript-eslint/no-explicit-any -- TODO: Replace 'any' with a more specific type.
    (input: any) => {
      const mockColumn = getSelectboxColumn(MOCK_CATEGORICAL_TYPE, {
        options: ["foo", "bar"],
      })
      const mockCell = mockColumn.getCell(input)
      expect(mockColumn.getCellValue(mockCell)).toEqual(null)
      expect(isMissingValueCell(mockCell)).toEqual(true)
    }
  )
})
